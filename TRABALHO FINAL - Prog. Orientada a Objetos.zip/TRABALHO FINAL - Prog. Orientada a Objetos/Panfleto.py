class Panfleto:
    __slots__ = ("__finalidade", "__instituicao")
    def __init__(self, finalidade, instituicao):
        self.__finalidade = finalidade
        self.__instituicao = instituicao
    @property
    def finalidade(self):
        return self.__finalidade
    @finalidade.setter
    def finalidade(self,nova):
        self.__finalidade = nova
    @property
    def instituicao(self):
       return self.__insituicao
    @instituicao.setter
    def instituicao(self, inst):
        self.__insituicao = inst